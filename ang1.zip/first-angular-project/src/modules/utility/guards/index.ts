import { UtilityGuard } from './utility.guard';

export const guards = [UtilityGuard];

export * from './utility.guard';
