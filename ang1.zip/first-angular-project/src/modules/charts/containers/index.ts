import { ChartsComponent } from './charts/charts.component';

export const containers = [ChartsComponent];

export * from './charts/charts.component';
